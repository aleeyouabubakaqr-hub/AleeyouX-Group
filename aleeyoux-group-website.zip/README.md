# AleeyouX Group — Static Website

This is a ready-to-deploy static site for **AleeyouX Group** with:
- Mobile-responsive layout
- Products with category tabs (All | Cosmetics | Beverages | Auto Care)
- Search bar
- Clickable product cards with modal + WhatsApp order
- Floating WhatsApp button
- Footer with quick links and social icons
- Contact section with WhatsApp and Email buttons

## Files
- `index.html` — main site
- `script.js` — product data, search, tabs, modal
- `assets/images/*` — placeholder images (replace with your real pictures)

## Edit Your Contact
- WhatsApp: `+234 814 789 4368` (edit in `index.html` and `script.js` if needed)
- Email: `aleeyouabubakaqr@gmail.com` (edit in `index.html`)

## Replace Product Images
Put your real images into `assets/images/` and keep the same filenames:
- `moskilla.jpg`
- `sipsmart.jpg`
- `sheaglow.jpg`
- `car-shampoo.jpg`
- `car-polish.jpg`

## How to Run Locally
Just double-click `index.html` (it opens in your browser). No installation required.

## How to Put Online (Free)
### Option 1 — Netlify (very easy)
1. Go to netlify.com → sign in.
2. Click **Add new site** → **Deploy manually**.
3. Drag the whole folder into Netlify. Done.

### Option 2 — GitHub Pages
1. Create a GitHub repo (public).
2. Upload all files.
3. Settings → Pages → Build from **/ (root)** → Save.
4. Your site goes live at `https://<yourname>.github.io/<repo>`.

### Option 3 — Vercel
1. Create a GitHub repo with these files.
2. Connect it on vercel.com → Deploy.

## Change Products or Categories
Open `script.js` and edit the `products` array to update names, prices, categories, and descriptions.
