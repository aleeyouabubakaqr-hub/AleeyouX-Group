// Mobile menu toggle
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
hamburger.addEventListener('click', () => {
  mobileMenu.style.display = mobileMenu.style.display === 'block' ? 'none' : 'block';
});

// Year
document.getElementById('year').textContent = new Date().getFullYear();

// Products data
const products = [
  { name: 'MosKilla Repellent', image: 'assets/images/moskilla.jpg', description: 'Strong mosquito repellent balm designed for Nigerian homes.', details: 'Formulated with gentle actives that repel mosquitoes effectively in Nigerian weather.', price: '₦1,500', category: 'Cosmetics' },
  { name: 'Sip Smart Hibiscus Drink', image: 'assets/images/sipsmart.jpg', description: 'Refreshing natural hibiscus drink in a can.', details: 'Made with premium hibiscus; smooth, tasty, and shelf-stable.', price: '₦500', category: 'Beverages' },
  { name: 'SheaGlow Butter', image: 'assets/images/sheaglow.jpg', description: 'Premium shea butter Vaseline for smooth skin.', details: '100% natural shea butter blend that hydrates and restores.', price: '₦2,000', category: 'Cosmetics' },
  { name: 'AleeyouX Car Shampoo', image: 'assets/images/car-shampoo.jpg', description: 'Powerful foaming shampoo, gentle on paint.', details: 'Lifts dirt, grease, and grime while protecting vehicle finishes.', price: '₦3,500', category: 'Auto Care' },
  { name: 'AleeyouX Car Polish', image: 'assets/images/car-polish.jpg', description: 'High-gloss polish for showroom shine.', details: 'Restores gloss, hides light scratches, and protects paint.', price: '₦5,000', category: 'Auto Care' },
];

const grid = document.getElementById('grid');
const searchInput = document.getElementById('searchInput');
const tabs = document.querySelectorAll('#tabs .tab');

let activeCategory = 'All';
let searchQuery = '';

function renderProducts() {
  grid.innerHTML = '';
  const filtered = products.filter(p => {
    const matchesCat = activeCategory === 'All' || p.category === activeCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery) || p.description.toLowerCase().includes(searchQuery);
    return matchesCat && matchesSearch;
  });

  if (filtered.length === 0) {
    grid.innerHTML = '<p class="col-span-full text-center text-gray-500">No products found.</p>';
    return;
  }

  filtered.forEach(p => {
    const card = document.createElement('div');
    card.className = 'rounded-2xl shadow border border-gray-100 hover:shadow-lg transition cursor-pointer';
    card.innerHTML = `
      <div class="p-6 text-center">
        <img src="${p.image}" alt="${p.name}" class="w-40 h-40 object-cover mx-auto mb-4 rounded-full shadow-lg"/>
        <h4 class="text-2xl font-semibold mb-2">${p.name}</h4>
        <p class="text-gray-600">${p.description}</p>
      </div>`;
    card.addEventListener('click', () => openModal(p));
    grid.appendChild(card);
  });
}

function setActiveTab(btn) {
  tabs.forEach(t => t.classList.remove('tab-active'));
  btn.classList.add('tab-active');
}

tabs.forEach(btn => {
  btn.addEventListener('click', () => {
    activeCategory = btn.dataset.cat;
    setActiveTab(btn);
    renderProducts();
  });
});
setActiveTab(document.querySelector('#tabs .tab[data-cat="All"]') || tabs[0]);

searchInput.addEventListener('input', (e) => {
  searchQuery = e.target.value.trim().toLowerCase();
  renderProducts();
});

// Modal
const modal = document.getElementById('modal');
const modalClose = document.getElementById('modalClose');
const modalImg = document.getElementById('modalImg');
const modalTitle = document.getElementById('modalTitle');
const modalDesc = document.getElementById('modalDesc');
const modalPrice = document.getElementById('modalPrice');
const modalBtn = document.getElementById('modalBtn');

function openModal(p) {
  modalImg.src = p.image;
  modalTitle.textContent = p.name;
  modalDesc.textContent = p.details;
  modalPrice.textContent = 'Price: ' + p.price;
  const msg = encodeURIComponent(`Hello AleeyouX Group, I would like to order: ${p.name} (Price: ${p.price})`);
  modalBtn.href = `https://wa.me/2348147894368?text=${msg}`;
  modal.classList.add('show');
}

modalClose.addEventListener('click', () => modal.classList.remove('show'));
modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.remove('show'); });

// Initial render
renderProducts();
